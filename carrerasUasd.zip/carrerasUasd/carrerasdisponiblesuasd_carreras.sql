-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: carrerasdisponiblesuasd
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `carreras`
--

DROP TABLE IF EXISTS `carreras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carreras` (
  `Id_carreras` int NOT NULL AUTO_INCREMENT,
  `Id_escuela` int NOT NULL,
  `Nombre_carrera` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id_carreras`),
  UNIQUE KEY `unique_carrera_escuela` (`Nombre_carrera`,`Id_escuela`),
  KEY `fk_Id_escuela` (`Id_escuela`),
  CONSTRAINT `fk_Id_escuela` FOREIGN KEY (`Id_escuela`) REFERENCES `escuelas` (`Id_escuela`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carreras`
--

LOCK TABLES `carreras` WRITE;
/*!40000 ALTER TABLE `carreras` DISABLE KEYS */;
INSERT INTO `carreras` VALUES (53,22,'Arquitectura'),(67,30,'Doctor en Medicina'),(72,31,'Doctor en Odontología'),(54,23,'Ingeniería Civil'),(31,11,'Ingeniería de Sistemas y Computación'),(29,11,'Ingeniería de Software'),(56,24,'Ingeniería Eléctrica en Potencia y Controles'),(28,11,'Ingeniería en Ciencias de Datos'),(30,11,'Ingeniería en Inteligencia Artificial y Robótica'),(32,11,'Ingeniería en Sistemas y Ciberseguridad'),(55,24,'Ingeniería en Telecomunicación y Sistemas Electrónicos'),(59,26,'Ingeniería Industrial'),(57,24,'Ingeniería Mecánica'),(58,25,'Ingeniería Química'),(79,33,'Ingeniero Agrónomo Mención: Desarrollo Agrícola y Rural'),(78,33,'Ingeniero Agrónomo Mención: Producción de Cultivos'),(77,33,'Ingeniero Agrónomo Mención: Suelo y Riego'),(82,35,'Ingeniero en Lácteo Alimentaria'),(81,35,'Ingeniero en Zootecnia'),(88,37,'Lic en Cinematografía y Audiovisuales Mención Cine'),(89,37,'Lic en Cinematografía y Audiovisuales Mención Televisión'),(80,34,'Licenciado en Medicina Veterinaria'),(109,40,'Licenciatura Dramaturgia y Dirección'),(137,60,'Licenciatura en Actividad Física, Salud y Fitness'),(108,40,'Licenciatura en Actuación'),(38,12,'Licenciatura en Administración de Empresas'),(51,21,'Licenciatura en Agrimensura'),(9,5,'Licenciatura en Antropología'),(85,36,'Licenciatura en Artes Visuales'),(114,56,'Licenciatura en Bibliotecología y Ciencias de la Información'),(61,27,'Licenciatura en Bioanálisis'),(18,9,'Licenciatura en Biología'),(16,8,'Licenciatura en Ciencia y Tecnología de Alimentos'),(20,10,'Licenciatura en Ciencias de la Atmósfera'),(21,10,'Licenciatura en Ciencias Geológica'),(49,20,'Licenciatura en Ciencias Políticas'),(40,13,'Licenciatura en Comercio Exterior y Aduanas'),(6,4,'Licenciatura en Comunicación mención Relaciones Públicas'),(45,17,'Licenciatura en Contabilidad'),(138,60,'Licenciatura en Cultura Física y Deportes'),(110,40,'Licenciatura en Danza Contemporánea'),(48,19,'Licenciatura en Derecho'),(96,38,'Licenciatura en Dirección Coral'),(102,39,'Licenciatura en Dirección y Creatividad Publicitaria'),(113,55,'Licenciatura en Diseño Artesanal y de ambientes'),(111,55,'Licenciatura en Diseño de Modas'),(103,39,'Licenciatura en Diseño Digital y Multimedia'),(101,39,'Licenciatura en Diseño Gráfico y Editorial'),(112,55,'Licenciatura en Diseño Industrial'),(39,13,'Licenciatura en Economía'),(94,54,'Licenciatura en Educación Artística'),(117,57,'Licenciatura en Educación Básica'),(129,59,'Licenciatura en Educación Especial e Inclusiva'),(136,60,'Licenciatura en Educación Física'),(118,57,'Licenciatura en Educación Infantil'),(119,57,'Licenciatura en Educación Inicial'),(124,58,'Licenciatura en Educación Media mención Biología y Química'),(125,58,'Licenciatura en Educación Media mención Ciencias Sociales'),(126,58,'Licenciatura en Educación Media mención Física y Matemáticas'),(127,58,'Licenciatura en Educación Media mención Francés'),(128,58,'Licenciatura en Educación Media mención Inglés'),(122,57,'Licenciatura en Educación mención Arte Escolar'),(115,56,'Licenciatura en Educación mención Bibliotecología'),(141,61,'Licenciatura en Educación mención Formación Humana y Ciudadanía'),(139,61,'Licenciatura en Educación Mención Gestión Educativa'),(116,56,'Licenciatura en Educación mención Informática Educativa'),(123,58,'Licenciatura en Educación mención Letras'),(130,59,'Licenciatura en Educación mención Orientación Académica'),(133,59,'Licenciatura en Educación mención Orientación Educativa y Psicopedagógica'),(132,59,'Licenciatura en Educación mención Orientación Para el Desarrollo de Recursos Humanos'),(131,59,'Licenciatura en Educación mención Orientación Socio-Comunitaria'),(120,57,'Licenciatura en Educación mención Primer Ciclo de Educación Primaria'),(121,57,'Licenciatura en Educación mención Segundo Ciclo de Educación Primaria'),(140,61,'Licenciatura en Educación para Personas Jóvenes y Adultas'),(64,28,'Licenciatura en Enfermería'),(86,36,'Licenciatura en Escultura'),(42,15,'Licenciatura en Estadística y Ciencias de Datos'),(65,29,'Licenciatura en Farmacia'),(3,2,'Licenciatura en Filosofía'),(19,10,'Licenciatura en Física'),(74,53,'Licenciatura en Fisioterapia'),(33,51,'Licenciatura en Geografía Mención Recurso Naturales y Ecoturístico'),(8,5,'Licenciatura en Historia'),(93,54,'Licenciatura en Historia y Crítica Del Arte'),(62,27,'Licenciatura en Imagenología'),(27,11,'Licenciatura en Informática'),(2,1,'Licenciatura en Lengua Española y Literatura orientada a la Educación'),(4,3,'Licenciatura en Lengua y Literatura Francesa'),(5,3,'Licenciatura en Lengua y Literatura Inglesa'),(1,1,'Licenciatura en Letras'),(76,53,'Licenciatura en Logopedia'),(41,14,'Licenciatura en Mercadotecnía'),(34,52,'Licenciatura en Microbiología y Parasitología'),(7,4,'Licenciatura en Periodismo'),(87,36,'Licenciatura en Plástica y Animación de Cómic'),(13,6,'Licenciatura en Psicología Clínica'),(14,6,'Licenciatura en Psicología del Desarrollo'),(10,6,'Licenciatura en Psicología Educativa'),(12,6,'Licenciatura en Psicología Organizacional'),(11,6,'Licenciatura en Psicología Social'),(100,39,'Licenciatura en Publicidad Mención Creatividad y Gerencia'),(98,39,'Licenciatura en Publicidad Mención Diseño'),(99,39,'Licenciatura en Publicidad Mención Ilustración'),(17,8,'Licenciatura en Química'),(44,16,'Licenciatura en Sociología'),(104,40,'Licenciatura en Teatro'),(105,40,'Licenciatura en Teatro Mención Actuación'),(106,40,'Licenciatura en Teatro Mención Dirección'),(107,40,'Licenciatura en Teatro Mención Dramaturgia'),(95,38,'Licenciatura en Teoría y Educación Musical'),(43,16,'Licenciatura en Trabajo Social'),(46,18,'Licenciatura en Turismo y Hostelería'),(15,7,'Licenciatura Matemática'),(75,53,'Licenciatura Terapia Ocupacional'),(52,21,'Plan de Nivelación para Egresados de Agrimensura'),(68,30,'Pre-Médica/Medicina'),(69,30,'Residencia Médica'),(90,37,'Técnico en Fotografía y Medios Audiovisuales'),(47,18,'Técnico en Gestíon en Alojamientos Túristicos'),(60,27,'Técnico Radiólogo'),(25,11,'Técnico Superior Desarrollo App Animación y Videojuegos'),(37,12,'Técnico Superior en Administración de Mipymes'),(26,11,'Técnico Superior en Administración de Redes'),(35,12,'Técnico Superior en Administración Pública'),(50,21,'Técnico Superior en Agrimensura'),(73,32,'Técnico Superior en Atención Pre-hospitalaria'),(91,37,'Técnico Superior en Cinematografía'),(23,11,'Técnico Superior en Desarrollo Aplicaciones Móviles'),(22,11,'Técnico Superior en Desarrollo De Software'),(134,60,'Técnico Superior en Educación Física'),(135,60,'Técnico Superior en Entrenamiento Deportivo'),(66,29,'Técnico Superior en Farmacia'),(84,35,'Técnico Superior en Gestión Ganadera'),(70,31,'Técnico Superior en Higiene Dental'),(24,11,'Técnico Superior en Infraestructura de Tic'),(71,31,'Técnico Superior en Laboratorio Dental'),(97,38,'Técnico Superior en Música'),(63,27,'Técnico Superior en Radioterapia y Dosimetría'),(36,12,'Técnico Superior en Servicios y Gestión Municipal'),(92,37,'Técnico superior en Televisión'),(83,35,'Tecnólogo en Procesos Lácteo Alimentario');
/*!40000 ALTER TABLE `carreras` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-12 15:29:03
