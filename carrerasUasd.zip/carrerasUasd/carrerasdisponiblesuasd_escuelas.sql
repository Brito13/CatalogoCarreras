-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: carrerasdisponiblesuasd
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `escuelas`
--

DROP TABLE IF EXISTS `escuelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escuelas` (
  `Id_escuela` int NOT NULL AUTO_INCREMENT,
  `Id_facultad` int NOT NULL,
  `Nombre_escuela` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`Id_escuela`),
  KEY `fk_id_facultad` (`Id_facultad`),
  CONSTRAINT `fk_id_facultad` FOREIGN KEY (`Id_facultad`) REFERENCES `facultades` (`Id_facultad`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escuelas`
--

LOCK TABLES `escuelas` WRITE;
/*!40000 ALTER TABLE `escuelas` DISABLE KEYS */;
INSERT INTO `escuelas` VALUES (1,1,'Escuela de Letras'),(2,1,'Escuela de Filosofía'),(3,1,'Escuela de Idiomas'),(4,1,'Escuela de Comunicación Social'),(5,1,'Escuela de Historia y Antropología'),(6,1,'Escuela de Psicología'),(7,2,'Escuela de Matemática'),(8,2,'Escuela de Química'),(9,2,'Escuela de Biología'),(10,2,'Escuela de Física'),(11,2,'Escuela de Informática'),(12,3,'Escuela de Administración'),(13,3,'Escuela de Economía'),(14,3,'Escuela de Mercadotecnia'),(15,3,'Escuela de Estadística'),(16,3,'Escuela de Sociología'),(17,3,'Escuela de Contabilidad'),(18,3,'Escuela de Turismo y Hotelería'),(19,4,'Escuela de Derecho'),(20,4,'Escuela de Ciencias Políticas'),(21,5,'Escuela de Agrimensura'),(22,5,'Escuela de Arquitectura'),(23,5,'Escuela de Ingeniería Civil'),(24,5,'Escuela de Ingeniería Electromecánica'),(25,5,'Escuela de Ingeniería Química'),(26,5,'Escuela de Ingeniería Industrial'),(27,6,'Escuela de Bioanálisis'),(28,6,'Escuela de Ciencias Fisiológicas'),(29,6,'Escuela de Ciencias Morfológicas'),(30,6,'Escuela de Enfermería'),(31,6,'Escuela de Farmacia'),(32,6,'Escuela de Medicina'),(33,6,'Escuela de Odontología'),(34,6,'Escuela de Salud Pública'),(35,7,'Escuela de Agronomía'),(36,7,'Escuela de Veterinaria'),(37,7,'Escuela de Zootecnia'),(38,8,'Escuela de Artes Plásticas'),(39,8,'Escuela de Cine, Televisión y Fotografía'),(40,8,'Escuela de Crítica e Historia del Arte'),(41,8,'Escuela de Diseño Industrial y de Moda'),(42,8,'Escuela de Publicidad'),(43,8,'Escuela de Teatro y Danza'),(44,8,'Escuela de Música'),(51,2,'Escuela de Ciencias Geográficas'),(52,2,'Escuela de Microbiología y Parasitología'),(53,6,'Escuela de Ciencias Fisiológicas'),(54,8,'Escuela de Crítica e Historia del Arte'),(55,8,'Escuela de Diseño Industrial y de Moda'),(56,9,'Escuela de Bibliotecología, Tecnología e Innovaciones Educativas'),(57,9,'Escuela de Formación Docente para la Educación Infantil y Básica (FIB)'),(58,9,'Escuela de Formación Docente para la Educación Media (FEM)'),(59,9,'Escuela de Orientación Educativa y Psicopedagogía'),(60,9,'Escuela de Formación Docente en Educación Física y Ciencias del Deporte'),(61,9,'Escuela de Teoría y Gestión Educativa');
/*!40000 ALTER TABLE `escuelas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-12 15:29:03
